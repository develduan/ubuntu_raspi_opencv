for i in `ls libopencv*`;
do
	patchelf --replace-needed ../../lib/libopencv_calib3d.so libopencv_calib3d.so $i
	patchelf --replace-needed ../../lib/libopencv_core.so libopencv_core.so $i
	patchelf --replace-needed ../../lib/libopencv_features2d.so libopencv_features2d.so $i
	patchelf --replace-needed ../../lib/libopencv_flann.so libopencv_flann.so $i
	patchelf --replace-needed ../../lib/libopencv_highgui.so libopencv_highgui.so $i
	patchelf --replace-needed ../../lib/libopencv_imgcodecs.so libopencv_imgcodecs.so $i
	patchelf --replace-needed ../../lib/libopencv_imgproc.so libopencv_imgproc.so $i
	patchelf --replace-needed ../../lib/libopencv_ml.so libopencv_ml.so $i
	patchelf --replace-needed ../../lib/libopencv_objdetect.so libopencv_objdetect.so $i
	patchelf --replace-needed ../../lib/libopencv_photo.so libopencv_photo.so $i
	patchelf --replace-needed ../../lib/libopencv_shape.so libopencv_shape.so $i
	patchelf --replace-needed ../../lib/libopencv_stitching.so libopencv_stitching.so $i
	patchelf --replace-needed ../../lib/libopencv_superres.so libopencv_superres.so $i
	patchelf --replace-needed ../../lib/libopencv_videoio.so libopencv_videoio.so $i
	patchelf --replace-needed ../../lib/libopencv_video.so libopencv_video.so $i
	patchelf --replace-needed ../../lib/libopencv_videostab.so libopencv_videostab.so $i
done






