for i in `ls *.3.2.0`;do
	na=${i%%.3.2*}
	echo $na

	nb=$na".3.2"
	echo $nb

	sudo ln -s $i $nb
	sudo chmod +x $nb

	sudo ln -s $nb $na
	sudo chmod +x $na

	sudo chmod -x $i
done
